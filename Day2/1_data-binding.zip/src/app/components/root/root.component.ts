import { AfterViewInit, Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements AfterViewInit {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  greetings: string;
  name!: string;
  count: number;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!";
    this.flag = false;
    this.h = 300;
    this.w = 300;
    this.greetings = "Hello";
    this.count = 0;
  }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS")?.addEventListener("click", () => {
    //   this.message = new Date().toLocaleTimeString();
    //   console.log(this.message);
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS")?.addEventListener("click", () => {
        this.message = new Date().toLocaleTimeString();
        console.log(this.message);
      });
    });
  }

  doChange() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorClick1() {
    alert("Anchor was clicked...");
  }

  anchorClick2(e: Event) {
    alert("Anchor was clicked...");
    e.preventDefault();
  }

  doUpdate(nameTxt: string) {
    this.greetings = `Hello, ${nameTxt}`;
  }

  increaseCount(cb: () => void) {
    this.count += 1;
    if (this.count < 50) {
      window.setTimeout(() => {
        this.increaseCount(cb);
      }, 100)
    } else {
      cb();
    }
  }

  inZone() {
    this.count = 0;
    this.message = "Started....";
    this.increaseCount(() => {
      this.message = "Completed...";
    });
  }

  outOfZone() {
    this.count = 0;
    this.message = "Started....";

    this.ngZone.runOutsideAngular(() => {
      this.increaseCount(() => {
        this.ngZone.run(() => {
          this.message = "Completed...";
        });
      });
    });
  }
}
