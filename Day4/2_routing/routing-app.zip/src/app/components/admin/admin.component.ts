import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UsersService } from 'src/app/services/users.service';
import { fadeInAnimation } from 'src/app/utilities/animations/fade-in.animation';

@Component({
  selector: 'admin',
  templateUrl: './admin.component.html',
  animations: [fadeInAnimation]
})
export class AdminComponent implements OnInit, OnDestroy {
  @HostBinding('@fadeInAnimation') fadeInAnimation = true;
  @HostBinding('style.diaplay') display = 'block';

  message: string;
  users?: Array<any>;
  gu_sub?: Subscription;

  constructor(private usersService: UsersService) {
    this.message = "Loading data, please wait...";
  }

  ngOnInit(): void {
    this.gu_sub = this.usersService.getAllUsers().subscribe({
      next: resData => {
        this.users = resData;
        this.message = "";
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  ngOnDestroy(): void {
    this.gu_sub?.unsubscribe();
  }
}
