import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bs-nav',
  templateUrl: './bs-nav.component.html',
  styleUrls: ['./bs-nav.component.css']
})
export class BsNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
