// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Post } from 'src/app/models/post.model';
// import { Subscription } from 'rxjs';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html',
//   styleUrls: ['./root.component.css']
// })
// export class RootComponent implements OnInit, OnDestroy {
//   url: string;
//   message: string;
//   posts?: Array<Post>;
//   get_sub?: Subscription;

//   constructor(private httpClient: HttpClient) {
//     this.url = "https://jsonplaceholder.typicode.com/posts";
//     this.message = "Loading Data, please wait...";
//   }

//   ngOnInit() {
//     this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe({
//       next: resData => {
//         this.posts = [...resData];
//         this.message = "";
//       },
//       error: (err: HttpErrorResponse) => {
//         this.message = err.message;
//       }
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_sub?.unsubscribe();
//   }
// }

// -----------------------------------------------------

// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpErrorResponse } from '@angular/common/http';
// import { Post } from 'src/app/models/post.model';
// import { Subscription } from 'rxjs';
// import { PostService } from 'src/app/services/post.service';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html',
//   styleUrls: ['./root.component.css'],
//   providers: [PostService]
// })
// export class RootComponent implements OnInit, OnDestroy {
//   message: string;
//   posts?: Array<Post>;
//   get_sub?: Subscription;

//   constructor(private postService: PostService) {
//     this.message = "Loading Data, please wait...";
//   }

//   ngOnInit() {
//     this.get_sub = this.postService.getAllPosts().subscribe({
//       next: resData => {
//         this.posts = [...resData];
//         this.message = "";
//       },
//       error: (err: HttpErrorResponse) => {
//         this.message = err.message;
//       }
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_sub?.unsubscribe();
//   }
// }

// -----------------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Post } from 'src/app/models/post.model';
import { Subscription } from 'rxjs';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css'],
  providers: [PostService]
})
export class RootComponent implements OnInit, OnDestroy {
  message: string;
  posts?: Array<Post>;
  get_sub?: Subscription;
  ins_sub?: Subscription;
  del_sub?: Subscription;

  constructor(private postService: PostService) {
    this.message = "Loading Data, please wait...";
  }

  ngOnInit() {
    this.get_sub = this.postService.getAllPosts().subscribe({
      next: resData => {
        this.posts = resData;
        this.message = "";
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  insertPost() {
    let newPost: Post = {
      userId: 1,
      id: 0,
      title: "Test",
      body: "Test"
    };

    this.message = "Inserting a new Record...";

    this.ins_sub = this.postService.insertPost(newPost).subscribe({
      next: resData => {
          this.posts?.unshift(resData);
          this.message = "Record Inserted...";
          setTimeout(() => {
            this.message = "";
          }, 2000);
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  deletePost(id: number, e: Event) {
    e.preventDefault();

    this.message = `Deleting a record with id: ${id}...`;

    this.del_sub = this.postService.deletePost(id).subscribe({
      next: () => {
        if (this.posts) {
          this.posts = [...this.posts.filter(p => p.id !== id)];
          this.message = "Record Deleted...";
          setTimeout(() => {
            this.message = "";
          }, 2000);
        }
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
    this.ins_sub?.unsubscribe();
    this.del_sub?.unsubscribe();
  }
}