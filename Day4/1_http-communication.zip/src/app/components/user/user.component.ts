import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: [UserService]
})
export class UserComponent implements OnInit {
  users?: Array<any>;
  flag: boolean;
  message?: string;
  get_sub?: Subscription;

  selectedUserId: string;
  selectedUserDetails?: any;

  constructor(private userService: UserService) {
    this.flag = false;
    this.selectedUserId = "";
  }

  ngOnInit(): void {
    this.get_sub = this.userService.getAllUsers().subscribe({
      next: resData => {
        this.users = resData;
        this.message = "";
        this.flag = true;
      }, error: (err: string) => {
        this.message = err;
      }
    });
  }

  // getDetails(event: Event) {
  //   console.log("Selected User: ", (event.target as HTMLInputElement).value);
  // }

  // getDetails(newValue: string, event: Event) {
  //   console.log("Selected User: ", newValue);
  // }

  getDetails(newValue: string) {
    // console.log("Selected User: ", newValue);
    this.userService.getUser(newValue).subscribe({
      next: resData => {
        this.selectedUserDetails = resData;
        console.log(this.selectedUserDetails);
      }, error: (err: string) => {
        this.message = err;
      }
    });
  }
}
