import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ManishLibOct22',
  template: `
    <h1 class="text-danger">This is a component, exposed from Manish's library in October 2022</h1>
  `,
  styles: [
  ]
})
export class ManishLibOct22Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
