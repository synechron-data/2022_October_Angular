import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ManishLibOct22Service {

  constructor() { }
}
