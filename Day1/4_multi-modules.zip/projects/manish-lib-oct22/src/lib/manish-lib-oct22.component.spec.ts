import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManishLibOct22Component } from './manish-lib-oct22.component';

describe('ManishLibOct22Component', () => {
  let component: ManishLibOct22Component;
  let fixture: ComponentFixture<ManishLibOct22Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManishLibOct22Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManishLibOct22Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
