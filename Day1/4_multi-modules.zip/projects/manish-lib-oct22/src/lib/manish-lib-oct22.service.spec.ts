import { TestBed } from '@angular/core/testing';

import { ManishLibOct22Service } from './manish-lib-oct22.service';

describe('ManishLibOct22Service', () => {
  let service: ManishLibOct22Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManishLibOct22Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
