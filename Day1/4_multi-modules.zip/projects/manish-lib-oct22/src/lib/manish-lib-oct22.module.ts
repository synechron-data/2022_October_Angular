import { NgModule } from '@angular/core';
import { ManishLibOct22Component } from './manish-lib-oct22.component';



@NgModule({
  declarations: [
    ManishLibOct22Component
  ],
  imports: [
  ],
  exports: [
    ManishLibOct22Component
  ]
})
export class ManishLibOct22Module { }
