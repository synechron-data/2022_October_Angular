import { InjectionToken } from "@angular/core";

export const AUTHORS_LIST_TOKEN = new InjectionToken<string>("AuthorsListDIToken");